var isDown = false;

document.querySelector(".container").addEventListener("mousedown",function(event){
    aaaa();
});
document.querySelector(".container").addEventListener("mouseup",function(event){
    
});

function aaaa(event)
{
    document.addEventListener("mousemove",function(event){
        var left = document.querySelector(".content").offsetLeft;
        console.log(left);
        left += event.movementX;
        
        console.log(left);
        document.querySelector(".content").style.left = left
    });
}