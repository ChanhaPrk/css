var myVar = 100;
test();
document.write("myVar is " + myVar);

function test() { 			
	var myVar = 50;
}