		function sumMulti(x, y) {
			if (x == y) return x * y;
			else return x + y;
		}

		console.log(sumMulti(5, 10));
		console.log(sumMulti(10, 10));