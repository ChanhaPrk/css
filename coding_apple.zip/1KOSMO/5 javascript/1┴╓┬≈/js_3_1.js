function closePage()
{
    window.close();
}