/*
	1 javascript datatype
        var     : variable
        Number
        String
        Boolean
        
        자바스크립트에서는
        숫자타입은 굳이 구분하지않는다.
        (숫자타입은 숫자타입을 뿐이다.)
	2 undefiend and null 
        =,==,===
	3 자료형을 정의하지않고, 데이터를 삽입하였을 경우
   *4 변수 생명주기
        local
        global
   *5 조건문    
        if 
        if ~ if else ~ else
        if ~ else 
    6 분기조건문     
        switch
		  case : 
			break;
		  default :
    7 반복문        
        for 
        while 
        do~while
*/

/*

    Number, String, Boolean
    
*/

var number = 10;
console.log('type of var number : ' + typeof number );
console.log('var number : ' + number );
var obj_number = new Number(10);
console.log('type of new Number(10) : ' +obj_number );
var string = 'Hello javascript';
console.log('type of var string : ' + typeof string );
console.log( string );
var obj_String = new String('Hello jjavascript');
console.log( 'type of String("hhh..") : ' + typeof obj_String );
console.log( obj_String.toString() );
console.log( 'string + string = ' + string + string );
console.log( obj_String + obj_String );
var istrue = false;
console.log('type of istrue : ' + typeof istrue );
console.log( istrue );
/* 

    undefiend and null 
    
            
     비교연산자 
     =
     ==
     ===
    세개의 기호에 대한 설명을 기술하십시오.
    
*/
console.log('--- 비교연산자 ---');
var myVar1;
var myVar2 = null;
console.log('type of myVar1 : ' + typeof myVar1 );
console.log( myVar1 );
console.log('type of myVar2 : ' + typeof myVar2 );
console.log( myVar2 );

//undefined,null은 값은 같지만,
//엄밀히 말하자면, 자료형까지는 같지 않다.

console.log( 'myVar1 == myVar2 → ' + false );
console.log( 'myVar1 === myVar2 → ' + false );

var number1 = 1;
var number2 = 1;
console.log( number1 == number2 );      //true
console.log( number1 === number2 );     //true

var variable1 = 1;
var variable2 = new Number(1);
console.log( variable1 == variable2 );  //true
console.log( variable1 === variable2 ); //false


console.log('--- 자료형 미정의 ---');
/*

    자료형을 정의하지않고, 데이터를 삽입하였을 경우
    선언없이 대입할 경우, 데이터의 타입에 따라 자료형이 결정된다.
    
    ( var a = 10)  != ( a = 10 )
    
    자료형 선언 
        camel / pascal / pathole

*/
myString = 'myString datatype is String';
myNumber = 10;
console.log( typeof myString );
console.log( typeof myNumber );

/*
    변수와 데이터 타임
        변수 범위
            자료형을 정의하지않으면   global
            자료형을 정의하였다면     local
            
    호이스팅??
    https://developer.mozilla.org/ko/docs/Glossary/Hoisting
*/
function func()
{
    v1 = 10;        //왜 이렇게 되는지 물어보자!
}
func();
console.log( 'v1 = ' + v1 );

//n;              //error
n = 10            //타입이 데이터에 맞게 설정됨
//var n;          //undefine
//var n = null;   //null
//var n = 10;     //10 

/*

    조건문 
        if
        if ~ else
        if ~ if else ~ else

*/
var gameName1 = 'starcraft';
var gameName2 = new String('starcraft');
if( gameName1 === gameName2 )//데이터와 자료형까지 같나요??
{
    console.log( '데이터와 자료형까지 같습니다.' );
}
else
{
    console.log( '아니요 다릅니다.' );
}
/*

    분기조건문
    switch ~ case ~ default
    
*/
//var game = 'starcraft';
var game = new String('starcraft'); //default
switch( game )
{
    case 'battleground' :
        console.log( game + ' type is FPS' );
        break;
    case 'LeagueOfLeguend' :
        console.log( game + ' type is AOS' );
        break;
    case 'starcraft' :
        console.log( game + ' type is RTS' );
        break;
    default :
        console.log( game + ' is not game' );
}

/*
    for
    while
    do~while
*/
document.write('<table border="1">' 
               + '<tr>'
               + '</tr>' );
for( var i = 2; i <= 9; i++ )
{
    document.write('</tr>');
    document.write('<td>' +  i + '단&nbsp&nbsp' + '</td>');
  for( var j = 1; j <= 9; j++ )
  {
     document.write( '<td>' + i + '*' + j + ' = ' + i * j + '&nbsp&nbsp</td>');
  }
    document.write('</tr>');
}
document.write('</table>');






/*
document.write('<table border="1"><tr>');
for( var i = 2; i <= 9; i++ )
{
    document.write('<td>');
  for( var j = 1; j <= 9; j++ )
  {
     document.write(  i + '*' + j + ' = ' + i * j + '<br>');
  }
    document.write('</td>');
}
document.write('</tr></table>');
*/


/*--------------------------------------------*/
var gugudan = 1;
document.write("<table border='1'>");
    for( var i = 1; i <= 9; i++ )
        {   
            document.write('<tr>');
            for( var j = 2; j <=9; j++ )
            {
                if( i == 1 )
                {
                    if( (j%gugudan)==0)
                    {
                        document.write('<td>' + j + '단</td>');
                    }
                }
                else if( (j%gugudan)==0)
                {
                     document.write('<td>' + j + '*' + i + ' = ' + i * j +'&nbsp&nbsp</td>');  
                }
            }
            document.write('</tr>');
        }
document.write('</table>');

var total1 = 0;
for( var idx = 1; idx <=10; idx++ )
{
    total1 += idx;
}
document.write('<h1>total = ' + total1 + '</h1>' );

var total2 = 0;
var number = 2;
for( var idx = 1; idx < 100; idx++ )
{
    if( ( idx % number ) == 1 )
    {
        total2 += idx;
    }
}
document.write('<h1>total = ' + total2 + '</h1>');

document.write('100에서 2까지 역순으로 짝수만 출력 : ');
for( var idx = 100; idx >=2; idx-- )
{
    if( (idx%2) == 0 )
    {
        document.write( idx + '&nbsp');
    }
}

document.write('<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>');





