/*
        html DOM는 다음과 같은 이벤트에 반응할 수 있습니다.
            DOM??( https://developer.mozilla.org/ko/docs/Web/API/Document_Object_Model/%EC%86%8C%EA%B0%9C )
            
        마우스,키보드
        웹페이지,이미지 로딩
        submit, input 변경 등등...

*/
function changetext( id )
{
    id.innerHTML = 'Oooops!';
}
function displayDate()
{
    document.getElementById('demo').innerHTML = Date();
}

var changed = true;
function changedQuardColor( event )
{
    if( changed )
    {
        event.style.backgroundColor = 'red';
        changed = false;
    }
    else
    {
        event.style.backgroundColor = 'gainsboro';
        changed = true;
    }
}


