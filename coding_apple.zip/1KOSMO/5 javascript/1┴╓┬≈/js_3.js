/*

    0 DOM and BOM 
        DOM : Document Object Model
        BOM : Browser Object Model 
	       1 window
           2 navigator 
           3 history...
           4 location
           5 screen
        
    1 on   load : 특정 페이지에 입장하였을때 호출
      on unload : 특정 페이지에 퇴장하였을때 호출

    3 onchange 
        입력을 완료하여 Enter를 눌렀을 때...
        
        input type의 tag에 변경이 이루어질경우 
        호출되는 함수입니다.
        
    4 onmousedown 
      onmouseup
      onclick
      atc...
      
    5 참고 https://www.w3schools.com/jsref/dom_obj_event.asp  
*/
function popUp()
{
    var newPage = 
    window.open('js_3_1.html','','left=0,top=0,width=400,height=300');
    //두번째 인자 '' -> 새 창으로 열기
    //          undefiened ->새 탭으로 열기
    //          _self -> 현재 창에서 열기
    
    if( newPage == null )
    {
        alert('팝업차단을 해제해주세요!');
    }
}
function inputUserId()
{
    //입력한 아이디를 모두 대문자로 변경한다.
    var userId = document.getElementById('user_id');
    userId.value = userId.value.toUpperCase();
}
function selectedNumber()
{
    var selected = document.getElementById('selected');
    
    document.write(selected.value);
}
function overedMouse()
{
    var querd = document.getElementById('querd');
    
    querd.style.backgroundColor = 'gray';
}
function outedMouse()
{
    var querd = document.getElementById('querd');
    
    querd.style.backgroundColor = '#D94A38';
}
function downMouse()
{
    var querd = document.getElementById('querd');
    
    querd.innerHTML = '클릭하셨습니다!.';
}
function upMouse()
{
    var querd = document.getElementById('querd');
    
    querd.innerHTML = '클릭하십시오!.';
}