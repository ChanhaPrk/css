- 2주 1일차 
    1. getAttribute, setAttribute를 이용하여, 작은 이미지에 마우스를 가져다놓으면 
        큰 이미지와 바꾸는 기능을 만들어 보자
    2. for() -> while() -> do~while()
    3. break
    4. continue
    5. function
    6. JSON( JavaScript Object Nonation )
    7. Object Array
    8. Date
    9. RegExp를 적용한 MemberJoin form 제작
    10. cookie
        w3school에서 이론과 예제를 보고 이해하면 될 정도로 공부하면 됨!!