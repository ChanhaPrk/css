func( 'hello' );
function func( string )
{
    document.write( string );
}
//func( 'hi' );
/*
    javascript에서는 함수를 정의하기전에 호출해도 
    정상적으로 실행된다.
*/

document.write( '<h1>Object of javascript</h1>' );
var employee = new Object();
employee.name = 'gildongHong';
employee.class = 'assasin';
employee.showInfo = function()
{
    document.write('name : ' + this.name );
    document.write('<br>');
    document.write('class : ' + this.class );
}
employee.showInfo();

document.write('<br><br><br>');

//생성자를 이용한 객체생성
var foo = function( name, age, nickName, job )
{
    this.name = name;
    this.age = age;
    this.nickName = nickName;
    this.job = job;
    
    /*    
        this.showInfo = function()
        {
            document.write( 'name : ' + this.name + '&nbsp' + 'age : ' + this.age + '&nbsp' +
            'nickName : ' + this.nickName + '&nbsp' + 'job : ' + this.job );
        }
    */
}
foo.prototype.showInfo = function()
{
        document.write( 'name : ' + this.name + '&nbsp' + 'age : ' + this.age + '&nbsp' +
        'nickName : ' + this.nickName + '&nbsp' + 'job : ' + this.job );
}
var tt = new foo( 'gildongHong', 30, 'pingkle', 'assasin' );
tt.showInfo();

document.write('<br><br><br>');

var ff = new foo( 'chanhaPark', 30, 'major', 'warrior' );
ff.showInfo();

/*
    javacript의 객체에 대해 이해했는가 휴먼?
    a와 b를 매개변수를 입력받아서 
    더하기, 빼기, 곱하기, 나누기를 계산하여 document.write()으로 출력하시오 휴먼!
*/
var ractangle = function( a, b )
{
    this.a = a;
    this.b = b;
    
    this.plus = function(){ document.write('call function plus'); }
    this.minas = function(){ document.write('call function minas'); }
    this.multi = function(){ document.write('call function multi'); }
    this.divis = function(){ document.write('call function divis'); }
}
ractangle.prototype.plus = function()
{
    document.write('call prototype function plus');
}
ractangle.prototype.minas = function()
{
    document.write('call prototype function minas');
}
ractangle.prototype.multi = function()
{
    document.write('call prototype function multi');
}
ractangle.prototype.divis = function()
{
    document.write('call prototype function divis');
}

document.write('<br><br><br>');

var rac1 = new ractangle( 10, 30 );
/*
    멤버 함수와 prototype 함수의 이름이 같을 경우
    왜 멤버 함수으로 호출될까??
    
    내일 물어보세여
*/

var circle = function( x, y, diameter, color )
{
    this.x = x;
    this.y = y;
    this.diameter = diameter;
    this.color = color;
    
    this.drawing = function()
    {
        document.write( this.x + '' + this.y + '' + this.diameter + '' + this.color );
        var position = ( this.x * this.x ) + (  this.y * this.y );
        var diameter2 = this.diameter / 2 ;
        document.write( position + '' + diameter2 );
    }
}
var circle1 = new circle( 10, 20, 3, 'red' );
circle1.drawing();

/*
	JSON 방식의 오브젝트 정의 
	var employee = {} 는 var employee = new Object()와 같습니다.
    
    var tp = new Object();
    tp.name = 'ggg';
    tp.age = 22;
    tp.showInfo = function()
    {
      document.write( this.name + '' + this.age );  
    };
    tp.showInfo();
*/
var tp = 
{
    name : 'dfdfd',
    age : 30,
    showInfo : function()
    {
        document.write( this.name + '' + this.age );  
    }
}
tp.showInfo();
tp.name = 'qqqqqqqqqqq';
tp.showInfo();

var obj1 = new Object( name )
{
    this.name = name;
}

/*----------------------------------------------------------------*/
//함수도 객체로 간주된다.
/*
    Function 생성자는 새 Function 객체를 만듭니다.
    이 생성자를 직접적으로 호출하여 동적으로 함수를 생성할 수 있으나 보안 문제와 eval과 비슷한 유사(훨씬 덜 심각한) 
    성능 문제가 발생할 수 있습니다. 
    하지만, eval과 달리 Function 생성자를 이용하면 전역 범위(global scope)에서 코드를 실행할 수 있고, 
    더 나은 프로그래밍 습관을 유도하며 더 효율적으로 코드를 최소화 할  수 있습니다.

    설명섹션
    Function 생성자로 생성되는 Function 객체는 함수가 생성될 때 구문 분석(parsing)이 이루어집니다. 
    이는 함수 표현식(function expression)이나 function 문(function statement)으로 함수를 정의하고 코드 내에서 그 함수를 호출하는 것보다 덜 효율적인데, 그 이유는 Function 생성자로 생성된 함수는 호출하는 코드의 나머지 부분과 같이 구문 분석되기 때문입니다.

    함수로 전달되는 모든 인수는 생성될 함수의 매개 변수 식별자 이름으로 전달되는 순서대로 처리됩니다.

    (new 연산자를 사용하지 않고) 함수로써 Function 생성자를 호출하는 것은 생성자로 호출하는 것과 같습니다. 하지만, new 연산자가 제거됨으로써 코드의 크기를 약간(4 바이트 더 작게) 줄일 수 있으므로 Function에 대해서는 new 연산자를 사용하지 않는 것이 좋습니다.
    
    Function의 속성과 메서드섹션
    전역 Function 객체는 자신의 메서드 또는 속성이 없습니다. 그러나, 그 자체로 함수이기에 Function.prototype에서 프로토타입 체인을 통해 일부 메서드 및 속성을 상속받습니다.
*/
var sum1 = Function( 'a','b','return a+b' );
function sum2( a, b )
{
    return a+b;
}
var3 = function( a,b )
{
    return a+b;
}

function myFunction( args1, args2, args3 )
{
    console.log( "I have an argument!" + args1 );
    
    console.log( args2.bar );
    
    args3();
}
myFunction( 'foo', {bar:'baz'}, function(){console.log('args3!')});

//args함수에 매개변수가 없는 형태
function myfunction()
{
    console( 'I hava an argument!' + args1);
    
    console.log( args2.bar );
    
    args3();
}