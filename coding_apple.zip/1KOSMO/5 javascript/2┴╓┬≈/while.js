document.write('<h1>for to while</h1>');
var idx = 1;
while( idx <= 100 )
{
    document.write( idx + '&nbsp');
    if( idx % 5 == 0 )
    {
        document.write('<br>');
    }
    idx++;
}

document.write('<br><br>');
document.write('<h1>do~while - break</h1>');


idx = 1;
do
{
    document.write( idx + '&nbsp');
    if( idx == 20 )
    {
        break;
    }
    idx++;
}while( idx <= 100 )
    
document.write('<br><br>');
document.write('<h1>do~while - continue</h1>');
idx = 0;
do
{
    idx++;
    if( idx % 5 == 0 )
    {
        document.write('<br>');
        continue;
    }
    document.write(idx+'&nbsp');
}while( idx <= 100 )
    
document.write('<h1>drawing the star</h1>');
for( var y = 5; y >= 0; y-- )
{
    for( var x = y; x > 0; x-- )
    {
        document.write('*');
    }
    document.write('<br>');
}
