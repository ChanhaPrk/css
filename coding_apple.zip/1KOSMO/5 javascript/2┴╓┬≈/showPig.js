var big = document.querySelector('#cup');
var small = document.querySelectorAll('.small');

for( var idx = 0; idx < small.length; idx++ )
{
    small[idx].onmouseover = function( ){
        var t = this.getAttribute('src');
        big.setAttribute('src',t);
    }
}
/*
    차이를 아시겠습니까 휴먼???
    
    small[idx].onmouseover = function( event ){
        console.log( event );
    }
    → MouseEvent {isTrusted: true, screenX: 
                    -906, screenY: 776, clientX: 676, clientY: 470, …}

    small[idx].onmouseover = function( ){
        console.log( this );
    }
    → <img src='image/coffee3.jpg' width='200' height='200' class='small'>
*/

var children = document.querySelectorAll('#small-pic > img');
var total = document.querySelector('#total_childrens');
for( var idx = 0; idx < children.length; idx++ )
{
    children[idx].addEventListener('mouseover',function(){
        var small_src = this.getAttribute('src');
        total.setAttribute('src',small_src);
    },false );
    
    children[idx].addEventListener('mouseleave',function(){
        total.setAttribute('src','image/childrens/total_children.jpg');
    },false);
}

total.addEventListener('mouseover',function(){
    var window_x = window.getm
},false);