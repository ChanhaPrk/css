var buttons = document.querySelectorAll('.tab-button');
var contents = document.querySelectorAll('.tab-content');

for (let i = 0; i < buttons.length; i++ ){
	buttons[i].addEventListener('click',function(){
		for( let j = 0; j < buttons.length; j++ )
        {
            buttons[j].classList.remove('active');
            contents[j].classList.remove('show');
        }
		buttons[i].classList.add('active');
		contents[i].classList.add('show');
	});
}